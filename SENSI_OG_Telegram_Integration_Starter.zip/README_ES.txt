# SENSI OG — paquete de integración inicial con Telegram

## Qué incluye
- `ThreeOneOSFive.ipa`: copia sin modificar de la aplicación que enviaste.
- `bot.py`: bot de Telegram privado con lista de acceso.
- `.env.example`: variables necesarias para ejecutarlo.

## Importante: alcance real de este paquete
La IPA que recibí contiene una aplicación iOS compilada, no el proyecto fuente de Xcode/Swift.
Por eso **no es posible conectar de forma fiable los comandos del bot con las funciones internas
de la app modificando solamente esta IPA**. Este paquete no altera ni re-firma la aplicación.

El bot sí tiene una base ejecutable: una vez que configures el token y lo ejecutes en un equipo
o servidor siempre encendido, responderá a `/start`, `/ayuda`, `/ping` y `/estado`, y rechazará
a cualquier usuario cuyo ID no sea `8833269908`. Los comandos todavía no controlan la app.

## Configuración segura

1. Abre Telegram y entra a `@BotFather`.
2. Usa `/mybots` para seleccionar `@SensiOG7_bot` y obtener/regenerar su token.
3. No compartas el token en chats ni lo subas a repositorios.
4. En un terminal, desde esta carpeta, define las variables:

   **macOS / Linux**
   ```bash
   export TELEGRAM_BOT_TOKEN='PEGA_AQUI_EL_TOKEN'
   export ADMIN_USER_ID='8833269908'
   python3 bot.py
   ```

   **Windows PowerShell**
   ```powershell
   $env:TELEGRAM_BOT_TOKEN='PEGA_AQUI_EL_TOKEN'
   $env:ADMIN_USER_ID='8833269908'
   py bot.py
   ```

5. Abre `@SensiOG7_bot` y envía `/start`.

No pongas el token dentro de `bot.py` ni dentro de la IPA. Si el token se expone, revócalo
inmediatamente desde `@BotFather` y genera uno nuevo.

## Para completar el control real de SENSI OG
Hace falta el proyecto original editable de Xcode/Swift (por ejemplo, `.xcodeproj`,
`.xcworkspace` y archivos `.swift`) y conocer qué acciones de la app quieres exponer.
La arquitectura recomendada es que la app y el bot se comuniquen con un backend autenticado;
el bot nunca debe ejecutar acciones arbitrarias ni confiar únicamente en el nombre de usuario.
