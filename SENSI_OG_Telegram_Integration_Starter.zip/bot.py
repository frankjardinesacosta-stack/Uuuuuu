#!/usr/bin/env python3
"""
SENSI OG - Telegram admin bot starter.
Only the Telegram account ID configured in ADMIN_USER_ID can use commands.
Requires Python 3.10+ and TELEGRAM_BOT_TOKEN in the environment.
"""
import json
import os
import time
import urllib.parse
import urllib.request
import urllib.error

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
ADMIN_ID = os.environ.get("ADMIN_USER_ID", "8833269908").strip()
API = f"https://api.telegram.org/bot{TOKEN}"

if not TOKEN:
    raise SystemExit(
        "Falta TELEGRAM_BOT_TOKEN. Configura el token de @SensiOG7_bot "
        "como variable de entorno; no lo publiques ni lo incluyas en el ZIP."
    )

def telegram(method, data=None, timeout=40):
    payload = urllib.parse.urlencode(data or {}).encode()
    req = urllib.request.Request(f"{API}/{method}", data=payload)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            result = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        raise RuntimeError(f"Telegram API HTTP {exc.code}: {body}") from exc
    if not result.get("ok"):
        raise RuntimeError(f"Telegram API error: {result}")
    return result["result"]

def send(chat_id, text):
    telegram("sendMessage", {"chat_id": chat_id, "text": text})

def handle(message):
    sender = str(message.get("from", {}).get("id", ""))
    chat_id = message.get("chat", {}).get("id")
    text = (message.get("text") or "").strip()

    # Reject every sender except the configured owner.
    if sender != ADMIN_ID:
        if chat_id is not None:
            send(chat_id, "⛔ Acceso denegado. Este bot es privado.")
        return

    command = text.split()[0].split("@")[0].lower() if text else ""
    if command in ("/start", "/ayuda", "/help"):
        send(chat_id,
             "🔐 SENSI OG — panel privado\n\n"
             "Comandos disponibles:\n"
             "/ping — comprobar que el bot responde\n"
             "/estado — ver el estado de este servicio\n"
             "/ayuda — mostrar esta ayuda\n\n"
             "Administrador autorizado: " + ADMIN_ID + "\n\n"
             "Nota: este servicio todavía no está conectado a las funciones "
             "internas de la IPA. Para eso hace falta el proyecto fuente "
             "de iOS y una API/backend de la aplicación.")
    elif command == "/ping":
        send(chat_id, "🏓 Pong. El bot está conectado a Telegram.")
    elif command == "/estado":
        send(chat_id,
             "🤖 Bot: activo\n"
             "🔒 Control de acceso: activo\n"
             "👤 Administrador: " + ADMIN_ID + "\n"
             "📱 Integración interna con SENSI OG: pendiente del código fuente.")
    else:
        send(chat_id, "Comando no reconocido. Escribe /ayuda.")

def main():
    print("SENSI OG Telegram bot iniciado. Administrador:", ADMIN_ID)
    # Clear any old webhook so long polling can receive updates.
    telegram("deleteWebhook", {"drop_pending_updates": "true"})
    offset = None
    while True:
        params = {"timeout": 30}
        if offset is not None:
            params["offset"] = offset
        try:
            updates = telegram("getUpdates", params, timeout=40)
            for update in updates:
                offset = update["update_id"] + 1
                message = update.get("message")
                if message:
                    try:
                        handle(message)
                    except Exception as exc:
                        print("Error procesando mensaje:", repr(exc))
        except KeyboardInterrupt:
            print("Bot detenido.")
            break
        except Exception as exc:
            print("Error de conexión/API:", repr(exc))
            time.sleep(5)

if __name__ == "__main__":
    main()
